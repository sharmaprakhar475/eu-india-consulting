<footer class="footer">
<div class="container-fluid">
<div id="map-row" class="row">
  <div class="col-md-4">
    <div style="display: flex;justify-content: center;align-items: center;height: 100%;"><img src="images/logo/logo-white-medium.png" width="300px" ></div>
  </div>
  <div class="col-md-4" style=" text-align:center;padding-left:10px;">
    <h2>Links</h2>
    <ul>
      <li><a href="#banner">Home</a></li>
      <li><a href="#services">Programs</a></li>
      <li><a href="#content-3-10">About</a></li>
      <!-- <li><a href="#gallery">Gallery</a></li>
      <li><a href="#pricing5">Price</a></li> -->
      <li><a href="#testimonials">Testimonials</a></li>
      <li><a href="#contact">Contact</a></li>
    </ul>
  </div>
	 <div class="col-md-4" style="text-align: center;padding-bottom: 30px;">
			<h2>Contact us</h2>
    		<address>
    			<strong>EU-India Consulting</strong><br>
    			23 Rue Henri Gorjus<br> 
          69004 Lyon France<br>
    			Phone: +33 (0) 6 86 71 95 94<br>
          Email: eu.indiaconsulting@gmail.com
    		</address>
	 </div>
	 </div>
   <p ><center style="font-size: 16px;color: #fff">© 2021 EU-India Consulting. </center></p>
</div>
</footer>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.26.0/axios.min.js" integrity="sha512-bPh3uwgU5qEMipS/VOmRqynnMXGGSRv+72H/N260MQeXZIK4PG48401Bsby9Nq5P5fz7hy5UGNmC/W1Z51h2GQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>